---
title: "初识TCGA数据库"
date: 2022-08-22T10:03:09Z
draft: false
tags: ["fetched","生信菜鸟团"]
---

https://mp.weixin.qq.com/s/2O8RDCXGrNSKLB2K_S07wg

---

