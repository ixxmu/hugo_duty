---
title: "挖掘单细胞数据证明你的基因的重要性"
date: 2022-08-22T10:06:50Z
draft: false
tags: ["fetched","生信技能树","marker"]
---

https://mp.weixin.qq.com/s/psjc_UwMRB2WbNHonHkTAg

---

