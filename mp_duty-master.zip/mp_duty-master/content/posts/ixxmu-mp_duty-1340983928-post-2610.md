---
title: "2022年金水+中原+二七+管城之小学资源总盘点（上）"
date: 2022-08-16T23:37:11Z
draft: false
tags: ["fetched","郑州楼市"]
---

https://mp.weixin.qq.com/s/HCom6xjmr2aMLZFAOokb2g

---

