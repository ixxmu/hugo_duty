---
title: "郑州人，一定要走出去"
date: 2022-08-14T12:58:00Z
draft: false
tags: ["fetched","郑州楼市"]
---

https://mp.weixin.qq.com/s/ap4jGXWiT3PiMIGXkrvJ2w

---

