---
title: "河南容不下一个大学城"
date: 2022-08-15T14:32:05Z
draft: false
tags: ["fetched","在下刘三刀"]
---

https://mp.weixin.qq.com/s/gfW7XqnsqpV3-6TI-hiuXA

---

