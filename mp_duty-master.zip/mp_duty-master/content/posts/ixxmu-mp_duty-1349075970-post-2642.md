---
title: "转录组数据三分组的差异分析方式"
date: 2022-08-24T08:36:52Z
draft: false
tags: ["fetched","生信菜鸟团"]
---

https://mp.weixin.qq.com/s/BHt_7WFCtKXIZwQYqhO8jA

---

同样的wt的3个样品的转录组数据，在两次差异都是对照组，在数据离散度方面居然表现迥然不同
from 技能树