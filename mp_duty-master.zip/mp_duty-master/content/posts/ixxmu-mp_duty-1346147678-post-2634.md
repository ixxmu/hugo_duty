---
title: "使用Rfam数据库注释基因组中的非编码RNA（ncRNA）"
date: 2022-08-22T10:06:19Z
draft: false
tags: ["fetched","小白鱼的生统笔记"]
---

https://mp.weixin.qq.com/s/jrQRdx8RKwtmgk0IGbuAWA

---

