---
title: "15+纯生信分型文章？讲好故事你也可以！"
date: 2022-08-09T15:25:25Z
draft: false
tags: ["fetched","医学僧的科研日记"]
---

https://mp.weixin.qq.com/s/3oJll69icjMRumczUYlJLA

---

