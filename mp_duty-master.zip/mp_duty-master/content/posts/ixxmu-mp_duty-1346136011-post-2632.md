---
title: "利用garnett鉴定细胞"
date: 2022-08-22T09:57:45Z
draft: false
tags: ["fetched","生信喵实验柴","marker"]
---

https://mp.weixin.qq.com/s/eLZISEKS9NZ4VuNUXvCNOw

---

