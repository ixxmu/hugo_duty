---
title: "“你了解那么多数据，是想干什么？”"
date: 2022-08-24T09:31:13Z
draft: false
tags: ["fetched","张佳玮写字的地方"]
---

https://mp.weixin.qq.com/s/MosC5nrKVZFQBN8_pHPv7w

---

“你了解那么多数据，是想干什么？” by 张佳玮写字的地方
------
Tt

<div><p><span>天下都说曹操奸雄，那是因为许劭“治世能臣，乱世奸雄”的评语。</span></p><p><span>但《三国演义》里，第一次有人面说曹操奸雄，是许攸。</span></p><p><br></p><p><span>当日许攸跳反到曹营，曹操赤脚出迎；许攸先开诚布公，说了自己试图让袁绍偷袭的策略，曹操也后怕不已。</span></p><p><span>按说许攸已先说了真相，轮到曹操了吧？</span></p><p><br></p><p><span>攸：“公今军粮尚有几何？”</span></p><p><span>操：“可支一年。”</span></p><p><span>攸笑：“恐未必。”——这是第一折。</span></p><p><span><br></span></p><p><span>操曰：有半年耳。”</span></p><p><span>攸拂袖而起，趋步出帐：“吾以诚相投，而公见欺如是，岂吾所望哉！”——第二折，你还骗我！</span></p><p><span><br></span></p><p><span>操挽留：“子远勿嗔，尚容实诉：军中粮实可支三月耳。”</span></p><p><span>攸笑：“世人皆言孟德奸雄，今果然也。”——第三折，“你果然是奸雄，这时候还哄我！”</span></p><p><span><br></span></p><p><span>操亦笑：“岂不闻兵不厌诈！” 遂附耳低言：“军中止有此月之粮。”</span></p><p><span>攸大声曰：“休瞒我！粮已尽矣！”操愕然曰：“何以知之？”</span></p><p><span>——许攸掀桌：我知道事情真相了！</span></p><p><span>曹操愕然。</span></p><p><br></p><p><img data-galleryid="" data-ratio="0.6696269982238011" data-s="300,640" data-src="https://mmbiz.qpic.cn/mmbiz_png/ichVicSguPRLlBkhfm9ubQv9Ao2JI01Hl5oqJLwo0QQqzr8tMVXhfp0CQfasxnRCRUwz19qA6eu7yibibq8XKQpbxg/640?wx_fmt=png&amp;wxfrom=5&amp;wx_lazy=1&amp;wx_co=1" data-type="png" data-w="563" src="https://mmbiz.qpic.cn/mmbiz_png/ichVicSguPRLlBkhfm9ubQv9Ao2JI01Hl5oqJLwo0QQqzr8tMVXhfp0CQfasxnRCRUwz19qA6eu7yibibq8XKQpbxg/640?wx_fmt=png&amp;wxfrom=5&amp;wx_lazy=1&amp;wx_co=1"></p><p><br></p><p><span>妙在曹操每一番推延，都还伴随着动作。</span></p><p><span>挽留，“容我说实话”；假笑，“兵不厌诈嘛！”还附耳说话。</span></p><p><span>这一段写得极妙，简直奸诈到可爱的地步了。</span></p><p><br></p><p><span>话说，曹操三推四推，挽留假笑，附耳低声，既因为他是奸雄，也因为<strong>数据实乃大事</strong>，不敢轻易透底。</span></p><p><br></p><p><span>战国时孙膑退兵减灶，虚报了兵力，就坑了庞涓。</span></p><p><span>刘宋的檀道济退兵时唱筹量沙，像是在数粮草，其实用沙土替换，不让敌军知道自己没粮草了。</span></p><p><span>一个道理。</span></p><p><br></p><p><span>刘邦入咸阳时，一时快活，想享受，张良和樊哙劝他赶紧走人，别留连富贵。</span></p><p><span>萧何当时在做啥呢？</span></p><p><span>他去找秦国的数据了。</span></p><blockquote data-type="2" data-url="" data-author-name="" data-content-utf8-length="97" data-source-title=""><section><p><span>沛公至咸阳，诸将皆争走金帛财物之府分之，何独先入收<strong>秦丞相御史律令图书</strong>藏之。沛公为汉王，以何为丞相。项王与诸侯屠烧咸阳而去。汉王所以<strong>具知天下阸塞，户口多少，强弱之处，民所疾苦者</strong>，以何具得秦图书也。</span></p></section></blockquote><p><span>刘邦后来一统天下，萧何后勤做得完美，就因为他<strong>掌握所有细节数据</strong>。<br></span></p><p><span>反过来证明，这些数据，大概并不是人人都看得到的。</span></p><p><span>甚至，大人物也不一定看得到真实数据。</span></p><p><span><br></span></p><p><span>《汉书·王莽传下》里，王莽听说百姓饥馑，问中黄门王业：</span></p><p><span>真相如何？百姓真的饿吗？</span></p><p><span><br></span></p><p><span>王业要哄王莽，去市集买了粱饭肉羹，拿回来告诉王莽：</span></p><p><span>老百姓都吃这个！</span></p><p><span>王莽还真信了。</span></p><p><span><br></span></p><p><span>大概在古代，</span><span>真实数据什么的，王业也不想让王莽知道，萧何能拿来当做独家战略优势。</span><span>等闲人想探头打听，还可能要被打屁股：</span></p><p><span>你现在就想知道数据，以后想干什么，我都不敢想！</span></p><p><span></span></p><p><span>明清两朝流行过一种搞法：</span></p><p><span><span>懂事的师爷，逢水旱，就上报一个极微妙的数字。那数字恰好好到老爷治理有功，能受嘉奖，又恰到好处地，能免一点钱粮，如此下面悦服。</span></span></p><p><span>反正各级师爷幕僚同气连枝，师出同门，心照不宣，维持个运转就是。</span></p><p><span></span></p><p><span>题外话，曹操藏得很严的数据，最后还是透给了许攸。</span></p><p><span>好在许攸献计取乌巢，曹操赢了官渡之战。</span></p><p><span><br></span></p><p><span>之后没多久，许攸就被许褚杀了，理由是“许攸无礼”。</span></p><p><span>曹操还责骂了许褚几句：“子远与吾旧交，故相戏耳，何故杀之？”深责许褚，令厚葬许攸。</span></p><p><span>毛宗岗评点说：</span></p><p><span>此奸雄假话。都是奸雄欺人之处。</span></p><p><br></p><p>无礼不无礼的，其实没那么要命；许攸真正的问题，还是知道太多了呀。<br></p><p><br></p><section><mp-common-profile data-pluginname="mpprofile" data-id="MzA5NjY2NTcxOA==" data-headimg="http://mmbiz.qpic.cn/mmbiz_png/ichVicSguPRLnF3fkiblQXmk32oMYjny8xmkhHQM8S17gSOGVU9Bsmic7uLABat3BOiaDBgMAr1FrGxxaFnt7gR3K9Q/0?wx_fmt=png" data-nickname="张佳玮写字的地方" data-alias="zhangjiawei_1983" data-signature="文学、艺术、体育、历史、旅行等题材的文字源。" data-from="0" data-is_biz_ban="0"></mp-common-profile></section><p><span></span></p><p><br></p></div>

---

测试 bbhhhj
