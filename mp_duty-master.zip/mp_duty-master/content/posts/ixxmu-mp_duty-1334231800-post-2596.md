---
title: "生存分析的图你也要拼接吗"
date: 2022-08-10T07:59:29Z
draft: false
tags: ["fetched","生信技能树"]
---

https://mp.weixin.qq.com/s/0QDLgMcB0faPGSnwvrITjg

---

