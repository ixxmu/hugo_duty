---
title: "跟着NC学pseudotime| monocle2 拟时序分析 + 树形图"
date: 2022-08-20T06:00:04Z
draft: false
tags: ["fetched","生信补给站"]
---

https://mp.weixin.qq.com/s/u50VeedGKnsCGIB-XsM4cw

---

