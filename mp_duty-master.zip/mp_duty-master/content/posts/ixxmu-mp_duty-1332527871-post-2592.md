---
title: "你研究的基因凭什么重要（这才是数据挖掘的用武之地）"
date: 2022-08-08T23:49:41Z
draft: false
tags: ["fetched","生信技能树"]
---

https://mp.weixin.qq.com/s/XIcoAvEO7eu0D5eOSbMWNA

---

获取含DFS信息的矩阵（从Cell整理的泛癌矩阵寻找

reportROC
