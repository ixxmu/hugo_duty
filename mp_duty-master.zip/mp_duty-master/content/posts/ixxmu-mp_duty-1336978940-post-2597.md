---
title: "《绝命律师》或成《绝命毒师》系列宇宙最终作品"
date: 2022-08-12T09:34:52Z
draft: false
tags: ["fetched","cnbeta"]
---

https://m.cnbeta.com/wap/view/1303773.htm

---

