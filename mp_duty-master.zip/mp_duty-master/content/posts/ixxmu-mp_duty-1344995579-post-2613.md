---
title: "GSEA分析后的通路上调还是下调呢"
date: 2022-08-20T00:17:42Z
draft: false
tags: ["fetched","生信技能树"]
---

https://mp.weixin.qq.com/s/iNnWETeFaXAN_zd51lIYGw

---

