## 📝[生信技能树](https://github.com/ixxmu/mp_duty/issues?q=label%3A%E7%94%9F%E4%BF%A1%E6%8A%80%E8%83%BD%E6%A0%91+is%3Aclosed)
<!-- 1issueTable -->

1. [挖掘单细胞数据证明你的基因的重要性](https://github.com/ixxmu/mp_duty/issues/2637) [![marker](https://img.shields.io/github/labels/ixxmu/mp_duty/marker)](https://github.com/ixxmu/mp_duty/labels/marker)
2. [不知道单细胞亚群特异性标记基因的出处？](https://github.com/ixxmu/mp_duty/issues/2630) [![marker](https://img.shields.io/github/labels/ixxmu/mp_duty/marker)](https://github.com/ixxmu/mp_duty/labels/marker)
3. [不知道单细胞亚群特异性标记基因的出处？](https://github.com/ixxmu/mp_duty/issues/2627) 
4. [GSEA分析后的通路上调还是下调呢](https://github.com/ixxmu/mp_duty/issues/2613) 
5. [我可能发现了发cancer discovery的秘密](https://github.com/ixxmu/mp_duty/issues/2604) 
<!-- 1issueTable -->
## 📝[单细胞天地](https://github.com/ixxmu/mp_duty/issues?q=label%3A%E5%8D%95%E7%BB%86%E8%83%9E%E5%A4%A9%E5%9C%B0+is%3Aclosed)
<!-- 2issueTable -->

1. [drug set enrichment analysis using clusterProfiler](https://github.com/ixxmu/mp_duty/issues/2626) 
2. [drug set enrichment analysis using clusterProfiler](https://github.com/ixxmu/mp_duty/issues/2615) 
3. [CBNplot：将富集分析结果和临床特征相关联](https://github.com/ixxmu/mp_duty/issues/2614) 
4. [文章发表：基于癌症干性识别索拉非尼的耐药机制](https://github.com/ixxmu/mp_duty/issues/2558) 
5. [听说你也在画dotplot，但是我不服！](https://github.com/ixxmu/mp_duty/issues/2376) 
<!-- 2issueTable -->

## 📝[果子学生信](https://github.com/ixxmu/mp_duty/issues?q=label%3A%E6%9E%9C%E5%AD%90%E5%AD%A6%E7%94%9F%E4%BF%A1+is%3Aclosed)
<!-- 3issueTable -->

1. [研究生的重要技能: 如何烧开一壶水？](https://github.com/ixxmu/mp_duty/issues/2511) 
2. [TCGA数据库构建生存预测模型之lasso回归](https://github.com/ixxmu/mp_duty/issues/2473) 
3. [墙裂推荐！统计方法如何选以及全代码作图实现。](https://github.com/ixxmu/mp_duty/issues/2465) 
4. [「小技巧」如何给Seurat瘦瘦身](https://github.com/ixxmu/mp_duty/issues/2419) 
5. [视频小教程：审稿人说我图太单薄，我决定给点颜色看看，满意了吧。](https://github.com/ixxmu/mp_duty/issues/2350) 
<!-- 3issueTable -->
