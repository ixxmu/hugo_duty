---
name: 请求存档
about: 新建一个抓取请求，请在正文内填写单个url。
title: "archive_request"
labels: [archive]
---
